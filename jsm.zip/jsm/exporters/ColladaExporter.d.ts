import {Object3D} from '../../../src/Three';

export class ColladaExporter {
	constructor();

	parse(object: Object3D, onDone: (res: any) => void, options: object): null;
}
