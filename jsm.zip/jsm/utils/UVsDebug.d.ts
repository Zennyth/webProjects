import {Geometry} from "../../..";

export function UVsDebug(geometry: Geometry, size: number): HTMLCanvasElement;
